package com.example.desertrtp;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class DesertRTPPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final Map<UUID, Long> rtpCooldowns = new HashMap<>();
    private final Random random = new Random();

    private File lobbyFile;
    private FileConfiguration lobbyConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        createLobbyConfig();

        // Ensure configured desert world exists or create/load it
        getOrCreateDesertWorld();

        getServer().getPluginManager().registerEvents(this, this);

        if (getCommand("rtp") != null) getCommand("rtp").setExecutor(this);
        if (getCommand("lobby") != null) getCommand("lobby").setExecutor(this);
        if (getCommand("setlobby") != null) getCommand("setlobby").setExecutor(this);

        getLogger().info("DesertRTP plugin enabled! LuckPerms permissions registered.");
    }

    private World getOrCreateDesertWorld() {
        String worldName = getConfig().getString("rtp.world", "desert_world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            getLogger().info("Desert world '" + worldName + "' not found. Creating a custom desert world...");
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.NORMAL);
            world = creator.createWorld();
            if (world != null) {
                getLogger().info("Successfully loaded desert world: " + worldName);
            } else {
                getLogger().severe("Failed to create desert world!");
            }
        }
        return world;
    }

    private void createLobbyConfig() {
        lobbyFile = new File(getDataFolder(), "lobby.yml");
        if (!lobbyFile.exists()) {
            lobbyFile.getParentFile().mkdirs();
            try {
                lobbyFile.createNewFile();
            } catch (IOException e) {
                getLogger().severe("Could not create lobby.yml!");
            }
        }
        lobbyConfig = YamlConfiguration.loadConfiguration(lobbyFile);
    }

    private void saveLobbyConfig() {
        try {
            lobbyConfig.save(lobbyFile);
        } catch (IOException e) {
            getLogger().severe("Could not save lobby.yml!");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can execute this command.");
            return true;
        }

        String cmd = command.getName().toLowerCase();

        switch (cmd) {
            case "rtp" -> {
                if (!player.hasPermission("backlobby.rtp")) {
                    String noPerm = getConfig().getString("rtp.no-permission-message", "<red>No permission.</red>");
                    player.sendMessage(miniMessage.deserialize(noPerm));
                    return true;
                }
                handleRTP(player);
            }
            case "lobby" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                    if (!player.hasPermission("backlobby.admin")) {
                        player.sendMessage(miniMessage.deserialize("<red>You do not have permission to reload.</red>"));
                        return true;
                    }
                    reloadConfig();
                    lobbyConfig = YamlConfiguration.loadConfiguration(lobbyFile);
                    getOrCreateDesertWorld();
                    player.sendMessage(miniMessage.deserialize("<green>DesertRTP configuration reloaded successfully!</green>"));
                    return true;
                }
                handleLobbyTeleport(player);
            }
            case "setlobby" -> {
                if (!player.hasPermission("backlobby.setlobby") && !player.hasPermission("backlobby.admin")) {
                    player.sendMessage(miniMessage.deserialize("<red>You do not have permission to set the lobby.</red>"));
                    return true;
                }
                handleSetLobby(player);
            }
        }
        return true;
    }

    private void handleRTP(Player player) {
        long cooldownSec = getConfig().getLong("rtp.cooldown-seconds", 30);
        long now = System.currentTimeMillis();

        if (rtpCooldowns.containsKey(player.getUniqueId()) && !player.hasPermission("backlobby.admin")) {
            long lastUse = rtpCooldowns.get(player.getUniqueId());
            long timePassed = (now - lastUse) / 1000;
            if (timePassed < cooldownSec) {
                long remaining = cooldownSec - timePassed;
                String msg = getConfig().getString("rtp.cooldown-message", "<red>Wait <seconds>s.</red>")
                        .replace("<seconds>", String.valueOf(remaining));
                player.sendMessage(miniMessage.deserialize(msg));
                return;
            }
        }

        String searchingMsg = getConfig().getString("rtp.searching-message", "<yellow>Searching for location...</yellow>");
        player.sendMessage(miniMessage.deserialize(searchingMsg));

        findSafeDesertLocationAsync().thenAccept(location -> {
            if (location == null) {
                String failMsg = getConfig().getString("rtp.fail-message", "<red>Failed to find location.</red>");
                player.sendMessage(miniMessage.deserialize(failMsg));
                return;
            }

            Bukkit.getScheduler().runTask(this, () -> {
                player.teleportAsync(location).thenAccept(success -> {
                    if (success) {
                        rtpCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
                        String tpMsg = getConfig().getString("rtp.teleport-message", "<green>Teleported!</green>");
                        player.sendMessage(miniMessage.deserialize(tpMsg));
                    }
                });
            });
        });
    }

    private CompletableFuture<Location> findSafeDesertLocationAsync() {
        return CompletableFuture.supplyAsync(() -> {
            World world = getOrCreateDesertWorld();
            if (world == null) return null;

            int minX = getConfig().getInt("rtp.min-x", -2000);
            int maxX = getConfig().getInt("rtp.max-x", 2000);
            int minZ = getConfig().getInt("rtp.min-z", -2000);
            int maxZ = getConfig().getInt("rtp.max-z", 2000);

            for (int attempt = 0; attempt < 100; attempt++) {
                int x = random.nextInt(maxX - minX + 1) + minX;
                int z = random.nextInt(maxZ - minZ + 1) + minZ;

                int highestY = world.getHighestBlockYAt(x, z);
                Location loc = new Location(world, x + 0.5, highestY + 1, z + 0.5);

                if (isLocationSafe(loc)) {
                    return loc;
                }
            }
            return null;
        });
    }

    private boolean isLocationSafe(Location loc) {
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        Block ground = world.getBlockAt(x, y - 1, z);
        Block feet = world.getBlockAt(x, y, z);
        Block head = world.getBlockAt(x, y + 1, z);

        if (!ground.getType().isSolid()) return false;
        if (ground.getType() == Material.LAVA || ground.getType() == Material.MAGMA_BLOCK || ground.getType() == Material.WATER) return false;
        return feet.getType().isAir() && head.getType().isAir();
    }

    private void handleSetLobby(Player player) {
        Location loc = player.getLocation();
        lobbyConfig.set("lobby.world", loc.getWorld().getName());
        lobbyConfig.set("lobby.x", loc.getX());
        lobbyConfig.set("lobby.y", loc.getY());
        lobbyConfig.set("lobby.z", loc.getZ());
        lobbyConfig.set("lobby.yaw", loc.getYaw());
        lobbyConfig.set("lobby.pitch", loc.getPitch());
        saveLobbyConfig();

        String msg = getConfig().getString("lobby.set-message", "<green>Lobby set!</green>");
        player.sendMessage(miniMessage.deserialize(msg));
    }

    private void handleLobbyTeleport(Player player) {
        if (!lobbyConfig.contains("lobby.world")) {
            player.sendMessage(miniMessage.deserialize("<red>Lobby spawn has not been set yet! Ask an admin to execute /setlobby.</red>"));
            return;
        }

        World world = Bukkit.getWorld(lobbyConfig.getString("lobby.world"));
        if (world == null) {
            player.sendMessage(miniMessage.deserialize("<red>Lobby world is currently unloaded or invalid!</red>"));
            return;
        }

        double x = lobbyConfig.getDouble("lobby.x");
        double y = lobbyConfig.getDouble("lobby.y");
        double z = lobbyConfig.getDouble("lobby.z");
        float yaw = (float) lobbyConfig.getDouble("lobby.yaw");
        float pitch = (float) lobbyConfig.getDouble("lobby.pitch");

        Location loc = new Location(world, x, y, z, yaw, pitch);
        player.teleportAsync(loc).thenAccept(success -> {
            if (success) {
                String msg = getConfig().getString("lobby.teleport-message", "<green>Welcome to the lobby!</green>");
                player.sendMessage(miniMessage.deserialize(msg));
            }
        });
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPlayedBefore() && getConfig().getBoolean("first-join.enabled", true)) {
            String titleText = getConfig().getString("first-join.welcome-title", "");
            String subtitleText = getConfig().getString("first-join.welcome-subtitle", "");
            String chatText = getConfig().getString("first-join.welcome-chat", "").replace("<player>", player.getName());

            if (!titleText.isEmpty() || !subtitleText.isEmpty()) {
                player.showTitle(Title.title(
                        miniMessage.deserialize(titleText),
                        miniMessage.deserialize(subtitleText)
                ));
            }

            if (!chatText.isEmpty()) {
                player.sendMessage(miniMessage.deserialize(chatText));
            }
        }
    }

    private boolean isInsideLobbyProtection(Location loc) {
        if (!getConfig().getBoolean("lobby.protection.enabled", true)) return false;

        String worldName = getConfig().getString("lobby.protection.world", "world");
        if (!loc.getWorld().getName().equalsIgnoreCase(worldName)) return false;

        double minX = getConfig().getDouble("lobby.protection.min-x");
        double maxX = getConfig().getDouble("lobby.protection.max-x");
        double minY = getConfig().getDouble("lobby.protection.min-y");
        double maxY = getConfig().getDouble("lobby.protection.max-y");
        double minZ = getConfig().getDouble("lobby.protection.min-z");
        double maxZ = getConfig().getDouble("lobby.protection.max-z");

        return loc.getX() >= Math.min(minX, maxX) && loc.getX() <= Math.max(minX, maxX)
                && loc.getY() >= Math.min(minY, maxY) && loc.getY() <= Math.max(minY, maxY)
                && loc.getZ() >= Math.min(minZ, maxZ) && loc.getZ() <= Math.max(minZ, maxZ);
    }

    private boolean canBypass(Player player) {
        return player.hasPermission("backlobby.owner") || player.hasPermission("backlobby.admin");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (isInsideLobbyProtection(event.getBlock().getLocation()) && !canBypass(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(miniMessage.deserialize(getConfig().getString("lobby.denied-build-message")));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isInsideLobbyProtection(event.getBlock().getLocation()) && !canBypass(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(miniMessage.deserialize(getConfig().getString("lobby.denied-build-message")));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (isInsideLobbyProtection(event.getBlock().getLocation()) && !canBypass(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (isInsideLobbyProtection(event.getBlock().getLocation()) && !canBypass(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> isInsideLobbyProtection(block.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFireSpread(BlockSpreadEvent event) {
        if (isInsideLobbyProtection(event.getBlock().getLocation()) && event.getNewState().getType() == Material.FIRE) {
            event.setCancelled(true);
        }
    }
}
